function s(e,x,y) {e.style.backgroundPosition = x + "px -" + y + "px"};
function do_the_twitter_dance(){
window.open('http://twitter.com/intent/tweet?text=H5BP Redux. HTML5 Boilerplate, with a few extra things added %20%3A&via=_daveyhiggins_&url='+location.href,'twitter-window','height=300,width=450')
}
function do_the_buffer_dance(){
window.open('http://bufferapp.com/add?text=H5BP Redux. HTML5 Boilerplate, with a few extra things added %20&source=button&count=vertical&url='+location.href,'buffer-window','height=300,width=450')
}
function do_the_fork_dance(){
window.open('https://github.com/higgo/h5bp-redux/')
}
$(document).ready(function(){

$('a').each(function() {
   var a = new RegExp('/' + window.location.host + '/');
   if(!a.test(this.href)) {
       $(this).click(function(event) {
           event.preventDefault();
           event.stopPropagation();
           window.open(this.href, '_blank');
       });
   }
});

$(".social").addSocial();

})
$(function () {
    $(window).hashchange(function () {
        var hash = location.hash;
        if ((hash.replace(/^#/, '') || 'blank') == 'source') {
            document.open();
            document.write('<script src="https://gist.github.com/2424875.js"><' + '\/script>');
            document.close()
        }
    });
    
    $(window).hashchange()
});